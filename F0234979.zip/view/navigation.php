<?php
//This page is a navigation templete  the website.
function navigationBar(){
    if (session_status()==PHP_SESSION_ACTIVE) {
        print("
   <html lang='en'>
<head>
       <meta charset='UTF-8'>
       <meta name='viewport' content='width=device-width, initial-scale=1.0'>
       <meta http-equiv='X-UA-Compatible' content='ie=edge'>
       <title>My Classified</title>
       <link rel='stylesheet' href='./css/bootstrap.css'>
   </head>
   <body>
    <nav class='navbar navbar-expand-lg navbar-light bg-success'>
   
           <!-- <a class='navbar-brand text-warning' href='#'>My Classified(Dashboard)</a>     -->
           <div class='navbar-expand' id='mainNavigation'>
               <ul class='navbar-nav'>
                   <li class='nav-item active nav-pills bg-bg-light'>
                       <a class='nav-link text-warning active ' href='./adminArea.php'>Home <span class='sr-only'></span></a>
                   </li>
                   <li class='nav-item col'>
                       <a class='nav-link text-warning' href='./viewItemsAdmin.php'>Items</a>
                   </li>
   
                   <li class='nav-item dropdown col-4 '>
                       <a class='nav-link dropdown-toggle text-warning' href='./viewCategory.php' id='dropdownMenu'>Categories</a>
                   </li>
                   <li class='nav-item dropdown col-6 '>
                       <a class='nav-link text-warning' href='./searchFormAdmin.php' id=''>Search</a>
                   </li>
           </div>
           <div class='navbar-nav ml-auto'>
               <li class=' nav-item active'>
                   <a class='nav-link active text-warning navbar-nav navbar-right'   href='./logout.php'name='logoutPage'>Logout</a>
               </li>
   
               </ul>
           </div>
       </nav>
");
    } elseif (session_status()==PHP_SESSION_NONE) {
        if ($_SERVER['REQUEST_URI']=="/comp1230/assignments/assignment2/index.php"||$_SERVER['REQUEST_URI']=="/comp1230/assignments/assignment2/") {
            print("   <!DOCTYPE html>
<html lang='en'>
<head>
<meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <meta http-equiv='X-UA-Compatible' content='ie=edge'>
    <title>My Classified</title>
    <link rel='stylesheet' href='./view/css/bootstrap.css'>
</head>
<body>
<nav class='navbar navbar-expand-lg navbar-light bg-success'>    
  <a class='navbar-brand text-warning' href='#'>My Classified</a>
  <div class='navbar-expand' id='mainNavigation'>
 <ul class='navbar-nav'>
      <li class='nav-item active nav-pills bg-bg-light'>
   <a class='nav-link text-warning active ' href='#'>Home <span class='sr-only'></span></a>
    </li>
    <li class='nav-item col'>
      <a class='nav-link text-warning' href='./view/viewItems.php'>Items</a>
    </li>
<li class='nav-item dropdown col-4 '>
       <a class='nav-link dropdown-toggle text-warning' href='./view/viewCategoryVisitor.php' id='dropdownMenu'>Categories</a>
    </li>
    <li class='nav-item dropdown col-6 '>
       <a class='nav-link text-warning' href='./view/searchForm.php' id=''>Search</a>
    </li>
  </div>
      <div class='navbar-nav ml-auto'>
          <li class=' nav-item active'>
          <a class='nav-link active text-warning navbar-nav navbar-right' href='./view/loginPage.php'>Login</a>
          </li>
</ul>
  </div>
  </nav> ");
        } else {
            print("   <!DOCTYPE html>
<html lang='en'>
<head>
<meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <meta http-equiv='X-UA-Compatible' content='ie=edge'>
    <title>My Classified</title>
    <link rel='stylesheet' href='./css/bootstrap.css'>
</head>
<body>
<nav class='navbar navbar-expand-lg navbar-light bg-success'>    
  <a class='navbar-brand text-warning' href='#'>My Classified</a>
  <div class='navbar-expand' id='mainNavigation'>
 <ul class='navbar-nav'>
      <li class='nav-item active nav-pills bg-bg-light'>
   <a class='nav-link text-warning active ' href='#'>Home <span class='sr-only'></span></a>
    </li>
    <li class='nav-item col'>
      <a class='nav-link text-warning' href='./viewItems.php'>Items</a>
    </li>
<li class='nav-item dropdown col-4 '>
       <a class='nav-link dropdown-toggle text-warning' href='./viewCategory.php' id='dropdownMenu'>Categories</a>
    </li>
    <li class='nav-item dropdown col-6 '>
       <a class='nav-link text-warning' href='./searchForm.php' id=''>Search</a>
    </li>
  </div>
      <div class='navbar-nav ml-auto'>
          <li class=' nav-item active'>
          <a class='nav-link active text-warning navbar-nav navbar-right' href='./loginPage.php'>Login</a>
          </li>
</ul>
  </div>
  </nav> ");
        }
    }
}

show_source(__FILE__);