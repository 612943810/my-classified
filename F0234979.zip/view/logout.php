<?php
//This logs out the sessions and website.

session_start();
require_once('../controller/User.php');
$userData=new User();
$userData->logoutSession();
show_source(__FILE__);