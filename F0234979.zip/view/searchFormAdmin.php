<?php
//This is a item search bar.
session_start();
require_once('./navigation.php');
navigationBar();
?>
<label for="searchBar">Search</label>
<input type="search" name="" id="searchBar">
    
</body>
</html>
<?php
show_source(__FILE__);
?>