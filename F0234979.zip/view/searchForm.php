<?php
//This is a item search bar.

require_once('./navigation.php');
navigationBar();
show_source(__FILE__);
echo "<br>";
?>
<label for="searchBar">Search</label>
<input type="search" name="" id="searchBar">
    
</body>
</html>