<?php
//This is the main index page opf the website.
require_once('./view/navigation.php');
navigationBar();
?>
    <article class="jumbotron">

        <h1 class><strong>Welcome My Classified Website</strong></h1>
 <h1>Feel free to look around the site</h1>
    </article>



</body>
</html>

<?php
show_source(__FILE__);
?>