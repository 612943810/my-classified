<?php
class DatabaseConnect extends PDO{
    //This function does database configuration 
public function __construct($pdoDSN="mysql:host=f0234979.gblearn.com;dbname=f0234979_comp1230;",$databaseUserName = "f0234979_user1",$databaseUserPassword = "mysql")
{ 
    parent::__construct($pdoDSN,$databaseUserName,$databaseUserPassword);  
    $this->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
}
private $databaseUserName,$databaseUserPassword;

    public function getDatabaseUserName()
    {
        return $this->databaseUserName;
    }

    public function setDatabaseUserName($databaseUserName)
    {
        $this->databaseUserName = $databaseUserName;

        return $this;
    }

    public function getDatabaseUserPassword()
    {
        return $this->databaseUserPassword;
    }


    public function setDatabaseUserPassword($databaseUserPassword)
    {
        $this->databaseUserPassword = $databaseUserPassword;

        return $this;
        show_source(__FILE__);
    }
    }

